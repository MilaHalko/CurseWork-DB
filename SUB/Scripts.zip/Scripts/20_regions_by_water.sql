create view regions_by_water as
select Name, count(lp.Id) as Water from region
join land_plot lp on region.Id = lp.RegionId
join communications c on lp.Id = c.LandPlotId
where Water = 1
group by region.Id
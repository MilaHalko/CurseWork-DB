create view area_of_landplot as
select  lp.Id, sum((RightDownLatitude - LeftUpLatitude)*(RightDownMagnitude-LeftUpMagnitude)) as Area
from land_plot_chunks
join land_plot lp on lp.Id = land_plot_chunks.LandPlotId
group by lp.Id
create view juridical_by_representative as
select pp.Surname, pp.Name,pp.Fathername ,jp.Name as CompanyName
from physical_person as pp join juridical_person as jp
on pp.JuridicalPersonId = jp.Id
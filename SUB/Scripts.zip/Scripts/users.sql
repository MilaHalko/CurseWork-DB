drop user if exists admin1;
create user admin1 identified by 'admin_password';
grant administrator to admin1;
set default role administrator to admin1;

drop user if exists teacher1;
create user teacher1 identified by 'teacher_password';
grant teacher to teacher1;
set default role teacher to teacher1;

drop user if exists student1;
create user student1 identified by 'student_password';
grant student1 to student;
set default role student to student1;


create table if not exists juridical_person
(
    Id   int auto_increment
        primary key,
    Name varchar(100) not null,
    constraint JuridicalPerson_Id_uindex
        unique (Id)
);

create table if not exists natural_resource
(
    id   int auto_increment
        primary key,
    Name varchar(30)   null,
    Tax  int default 0 not null,
    constraint tax_check check (Tax>=0),
    constraint Natural_resources_id_uindex
        unique (id)
);

create table if not exists physical_person
(
    Id                int auto_increment
        primary key,
    Name              varchar(30) not null,
    Surname           varchar(30) not null,
    Fathername        varchar(30) not null,
    DateOfBirth       date        not null,
    JuridicalPersonId int         null,
    constraint PhysicalPerson_Id_uindex
        unique (Id),
    constraint physicalperson_JuridicalPersonId_uindex
        unique (JuridicalPersonId),
    constraint physicalperson_juridicalperson_Id_fk
        foreign key (JuridicalPersonId) references juridical_person (Id)
            on update cascade on delete cascade
);

create table if not exists region
(
    Id   int auto_increment
        primary key,
    Name varchar(50)     not null,
    Tax  float default 0 not null,
    constraint Region_Id_uindex
        unique (Id),
    constraint Region_Name_uindex
        unique (Name),
    constraint tax_check check (Tax>=0)
);

create table if not exists registrator
(
    Id   int auto_increment
        primary key,
    Name varchar(60) null,
    constraint Registrator_Id_uindex
        unique (Id)
);

create table if not exists usage_type
(
    Id   int auto_increment
        primary key,
    Name varchar(50)   not null,
    Tax  int default 0 not null,
    constraint usage_type_Id_uindex
        unique (Id),
    constraint tax_check check (Tax>=0)
);

create table if not exists land_plot
(
    Id          int auto_increment
        primary key,
    OwnerId     int null,
    UsageTypeId int null,
    RegionId    int null,
    constraint LandPlot_Id_uindex
        unique (Id),
    constraint land_plot_physical_person_Id_fk
        foreign key (OwnerId) references physical_person (Id)
            on update cascade,
    constraint land_plot_region_Id_fk
        foreign key (RegionId) references region (Id)
            on update cascade,
    constraint land_plot_usage_type_Id_fk
        foreign key (UsageTypeId) references usage_type (Id)
            on update cascade on delete set null
);

create table if not exists action
(
    Id            int auto_increment
        primary key,
    LandPlotId    int  not null,
    SellerId      int  not null,
    CustomerId    int  not null,
    RegistratorId int  not null,
    Date          date not null,
    constraint Action_Id_uindex
        unique (Id),
    constraint Action_land_plot_Id_fk
        foreign key (LandPlotId) references land_plot (Id)
            on update cascade,
    constraint Action_physical_person_Id_fk
        foreign key (SellerId) references physical_person (Id)
            on update cascade,
    constraint Action_physical_person_Id_fk_2
        foreign key (CustomerId) references physical_person (Id)
            on update cascade,
    constraint action_registrator_Id_fk
        foreign key (RegistratorId) references registrator (Id)
            on update cascade
);

create table if not exists communications
(
    Electricity tinyint(1) default 0 not null,
    Water       tinyint(1) default 0 not null,
    Sewerage    tinyint(1) default 0 not null,
    LandPlotId  int                  null,
    constraint communications_LandPlotId_uindex
        unique (LandPlotId),
    constraint communications_land_plot_Id_fk
        foreign key (LandPlotId) references land_plot (Id)
);

create table if not exists land_plot_chunks
(
    Id                 int auto_increment
        primary key,
    LeftUpLatitude     float null,
    LeftUpMagnitude    float null,
    RightDownLatitude  float null,
    RightDownMagnitude float null,
    LandPlotId         int   null,
    NaturalResourcesId int   null,
    constraint land_plot_chunks_land_plot_Id_fk
        foreign key (LandPlotId) references land_plot (Id)
            on update cascade on delete cascade,
    constraint land_plot_chunks_natural_resource_id_fk
        foreign key (NaturalResourcesId) references natural_resource (id)
            on update cascade,
    constraint check_latitude check ( LeftUpLatitude < RightDownLatitude ),
    constraint check_magnitude check ( LeftUpMagnitude < RightDownMagnitude)
);

create trigger 'physical_person_before_insert' before insert on 'physical_person' for each row
    begin
        if datediff(curdate(), NEW.DateOfBirth)/365 <=18 then
            signal sqlstate '45000'
            set MESSAGE_TEXT = 'Client is under 18 years';
        end if;
    end;

create trigger 'action_before_insert' before insert on 'action' for each row
    begin
        if New.Date > CURDATE() then
            signal sqlstate '45000'
            set MESSAGE_TEXT = 'Date is in future';
        end if;
    end;

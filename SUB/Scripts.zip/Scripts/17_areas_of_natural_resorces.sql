create view areas_of_natural_resources as
select nr.Name,sum((RightDownLatitude - LeftUpLatitude)*(RightDownMagnitude-LeftUpMagnitude)) as TotalArea from land_plot_chunks lpc
join natural_resource nr on lpc.NaturalResourcesId = nr.id
group by nr.id
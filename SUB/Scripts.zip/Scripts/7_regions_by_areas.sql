create view regions_by_area as
select region.Name, sum(Area) as TotalArea from region
join land_plot lp on region.Id = lp.RegionId
join area_of_landplot on area_of_landplot.Id = lp.Id
group by region.Id
order by TotalArea desc
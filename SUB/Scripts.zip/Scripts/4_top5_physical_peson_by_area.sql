create view Top5_landplot_owners_by_area as
select Surname, Name, Fathername, sum(Area) as AreaSum from physical_person
join land_plot lp on physical_person.Id = lp.OwnerId
join area_of_landplot on lp.Id = area_of_landplot.Id
group by (physical_person.Id)
order by AreaSum desc
LIMIT 5

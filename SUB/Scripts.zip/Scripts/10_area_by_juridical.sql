create view area_by_juridical as
select juridical_person.Name, sum(Area) as TotalArea from juridical_person
join physical_person pp on juridical_person.Id = pp.JuridicalPersonId
join land_plot lp on pp.Id = lp.OwnerId
join area_of_landplot on area_of_landplot.Id = lp.Id
group by juridical_person.Id
order by TotalArea desc
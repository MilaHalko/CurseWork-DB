drop role if exists administrator;
create role administrator;
grant all privileges on *.* TO administrator;

drop role if exists teacher;
create role teacher;
grant DELETE, INSERT, SELECT, UPDATE on cadastredb.* TO teacher;

drop role if exists `student`;
create role `student`;
grant SELECT on cadastredb.* TO `student`;

flush privileges;
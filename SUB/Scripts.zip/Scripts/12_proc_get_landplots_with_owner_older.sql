drop procedure if exists  GetLandplotWithOwnerOlder;
create procedure GetLandplotWithOwnerOlder(age int)
begin
    select land_plot.Id, pp.Surname, pp.Name, pp.DateOfBirth from land_plot
    join physical_person pp on pp.Id = land_plot.OwnerId
    where DATEDIFF(CURDATE(), pp.DateOfBirth)/365 > age;
end;
call   GetLandplotWithOwnerOlder(70);
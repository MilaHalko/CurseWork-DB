drop procedure if exists  GetActionsBetween;
create procedure GetActionsBetween(start date, end date)
begin
    select (CONCAT(seller.Name, ' ', seller.Surname)) as Seller,
            (CONCAT(customer.Name, ' ', customer.Surname)) as Customer,
           a.Date
    from action a
        join physical_person customer on customer.Id = a.CustomerId
        join physical_person seller on seller.Id = a.SellerId
    where a.Date > start and a.Date < end;

end;
 call GetActionsBetween('2001-1-1', '2020-1-1')
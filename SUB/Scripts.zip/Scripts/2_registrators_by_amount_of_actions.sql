create view registrators_by_amount_of_actions as
select  rg.Name, COUNT(*) as Actions
from registrator as rg join action a on rg.Id = a.RegistratorId
group by rg.Name
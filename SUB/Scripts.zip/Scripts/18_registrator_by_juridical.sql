create view registrator_by_juridical as
select r.Name as Registrator, jp.Name as Company from action
join physical_person pp on pp.Id = action.CustomerId
join juridical_person jp on jp.Id = pp.JuridicalPersonId
join registrator r on action.RegistratorId = r.Id

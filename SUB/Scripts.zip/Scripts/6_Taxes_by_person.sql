create view taxes_by_person as
select physical_person.Surname,physical_person.Name,physical_person.Fathername,  IFNULL(sum(nr.Tax)*Area*1000, 0)+ sum(r.Tax)+ sum(ut.Tax)*1000*Area as Tax from physical_person
join land_plot lp on physical_person.Id = lp.OwnerId
join area_of_landplot on area_of_landplot.Id = lp.Id
join region r on lp.RegionId = r.Id
join land_plot_chunks lpc on lp.Id = lpc.LandPlotId
left join natural_resource nr on lpc.NaturalResourcesId = nr.id
join usage_type ut on lp.UsageTypeId = ut.Id
group by physical_person.Id
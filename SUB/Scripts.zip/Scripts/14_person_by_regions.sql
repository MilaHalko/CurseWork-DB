create view person_by_region as
select pp.Surname, pp.Name as Name, pp.Fathername, r.Name as Region from physical_person pp
join land_plot lp on pp.Id = lp.OwnerId
join region r on lp.RegionId = r.Id
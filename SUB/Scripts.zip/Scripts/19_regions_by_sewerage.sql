create view regions_by_sewerage as
select Name, count(lp.Id) as Sewerage from region
join land_plot lp on region.Id = lp.RegionId
join communications c on lp.Id = c.LandPlotId
where Sewerage = 1
group by region.Id
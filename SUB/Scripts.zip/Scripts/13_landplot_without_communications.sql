create view landplot_without_communications as
select land_plot.Id from land_plot
join communications c on land_plot.Id = c.LandPlotId
where c.Electricity = 0 and c.Water = 0 and c.Sewerage = 0
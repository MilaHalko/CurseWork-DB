create view natural_resource_by_person as
select physical_person.Surname, physical_person.Name as Name, physical_person.Fathername, nr.Name as NaturalResource from physical_person
join land_plot lp on physical_person.Id = lp.OwnerId
join land_plot_chunks lpc on lp.Id = lpc.LandPlotId
join natural_resource nr on lpc.NaturalResourcesId = nr.id
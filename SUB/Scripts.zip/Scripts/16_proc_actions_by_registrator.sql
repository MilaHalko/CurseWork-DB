drop procedure if exists  ActionsByRegistrator;
create procedure ActionsByRegistrator(SearchId int)
begin
    select (CONCAT(seller.Name, ' ', seller.Surname)) as Seller,
            (CONCAT(customer.Name, ' ', customer.Surname)) as Customer,
           Date,
           r.Name
    from action a
        join physical_person customer on customer.Id = a.CustomerId
        join physical_person seller on seller.Id = a.SellerId
        join registrator r on a.RegistratorId = r.Id
    where RegistratorId = SearchId
    order by Date;
end;
 call ActionsByRegistrator(2)
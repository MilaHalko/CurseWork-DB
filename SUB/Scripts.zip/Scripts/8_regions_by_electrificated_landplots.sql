    create view regions_by_electrificated_landplots as
    select Name, count(lp.Id) as Electrificated from region
    join land_plot lp on region.Id = lp.RegionId
    join communications c on lp.Id = c.LandPlotId
    where Electricity = 1
    group by region.Id
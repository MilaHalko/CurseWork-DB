create view areas_by_usage_type as
    select usage_type.Name, sum(area_of_landplot.Area) as TotalArea from usage_type
    join land_plot lp on usage_type.Id = lp.UsageTypeId
    join area_of_landplot on area_of_landplot.Id = lp.Id
    group by usage_type.Id
    order by TotalArea desc
